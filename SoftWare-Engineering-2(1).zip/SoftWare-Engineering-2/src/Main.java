import java.io.IOException;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) throws IOException {
		Scanner Scan=new Scanner(System.in);
		String S1;
		String S2;
        MainInfo object=new MainInfo();
        int x;
     	System.out.print("1.Signup\n");
     	System.out.print("2.Signin\n");
     	x=Scan.nextInt();
        switch(x) {
        case 1:
    		System.out.print("Enter username:\n");
    		S1=Scan.next();
		    System.out.print("Enter usertype:\n");
		    System.out.print("1.Buyer\n");
		    System.out.print("2.Store Owner\n");
    		S2=Scan.next();
    		switch(S2) {

    		case "1":
                Buyer buyer=new Buyer(S1,S2,x);
                break;
    		case "2":
    			Store SO=new Store(S1,S2,x);
    			break;	
    		}
            break;
        case 2:
    		System.out.print("Enter username:\n");
    		S1=Scan.next();
    		System.out.print("Enter password:\n");
    		S2=Scan.next();
    		switch(object.getUsertype(S1)) {

    		case "1":
                Buyer buyer=new Buyer(S1,S2);
                break;
    		case "2":
    			Store SO=new Store(S1,S2);
    			break;
    		case "#":
    			Admin admin=new Admin(S1,S2);
    			break;
    			
    		}

            break;
            default:
            	System.out.print("Wrong input.");
            	break;
        	
        }
      Scan.close();
        


}
}


