import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class PlatForm {
	private static String[] Categories;
	private static String[][] Brands=new String[2][];
	
public PlatForm() throws FileNotFoundException

	{
		String[] ArrayList;
		String home = System.getProperty("user.home");
		File f = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Categories"+ File.separator + "Categories.txt");
		Scanner Scan=new Scanner(f);
		String input=Scan.nextLine();
		String K="-";
		ArrayList=input.split(K);
		Categories=new String [ArrayList.length+1];
		for(int i=0;i<ArrayList.length;i++) {
			Categories[i]=ArrayList[i];
		}

		System.out.print("Enter Category to add:\n");
		Scan=new Scanner(System.in);
		this.Categories[ArrayList.length]=Scan.next();

	       PrintWriter writer;
			
				writer = new PrintWriter(f.getAbsolutePath());
			    
				for(int i=0;i<this.Categories.length;i++) {
					writer.print(this.Categories[i]+"-");
				}
				System.out.print("Category added!.");
			
				    writer.close();    


		
	}		
		





public PlatForm(int y) {
	String[] ArrayList1;
	String[] ArrayList2;
	int l=0;
	String k="-";
	String home = System.getProperty("user.home");
	File f = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Brands"+ File.separator + "Brands.txt");
	Scanner Scan;
	try {
		Scan = new Scanner(f);
		String input1=Scan.nextLine();
		//System.out.print(input1+"\n");
		String input2=Scan.nextLine();
		//System.out.print(input2+"\n");
		
		ArrayList1=input1.split(k);
		ArrayList2=input2.split(k);
		Brands=new String[2][ArrayList1.length+1];
		for(int i=0;i<ArrayList1.length;i++) {
			this.Brands[0][i]=ArrayList1[i];
			//System.out.print(Brands[0][i]+" ");
		}
		for(int i=0;i<ArrayList1.length;i++) {
			this.Brands[1][i]=ArrayList2[i];
			//System.out.print(Brands[1][i]+" ");
		}
		l=ArrayList1.length;
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
}


	Scan=new Scanner(System.in);
	System.out.print("Enter Brandname:\n");
	Brands[0][l]=Scan.next();
	System.out.print("Enter Brand Category:\n");
	Brands[1][l]=Scan.next();
	PrintWriter writer;
	l++;
	
		try {
			writer=new PrintWriter(f.getAbsolutePath());
			for(int i=0;i<2;i++) {
				for(int t=0;t<l;t++) {
					writer.write(Brands[i][t]+"-");
				}
				writer.write("\n");
		}
			writer.flush();
			writer.close();
		}
			catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		




	
System.out.print("Brand Added!.\n");




}



public PlatForm(String x) {
	
}






public void getBrand() {
	String[] ArrayList1=null;
	String[] ArrayList2=null;
	int l=0;
	String k="-";
	String home = System.getProperty("user.home");
	File f = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Brands"+ File.separator + "Brands.txt");
	Scanner Scan;
	String input1;
	String input2;

		try {
			Scan = new Scanner(f);
			input1=Scan.nextLine();
			//System.out.print(input1+"\n");
			input2=Scan.nextLine();
			//System.out.print(input2+"\n");
			ArrayList1=input1.split(k);
			ArrayList2=input2.split(k);
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=0;i<ArrayList1.length;i++) {
			System.out.print("Brandname:"+ArrayList1[i]+"\n");
			System.out.print("Brand Category:"+ArrayList2[i]+"\n");
		}
	
		
		
}

}


