import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Store extends MainInfo implements AlterFiles {
	
	private String Sname;
	private String Stype;
	private String Slocation;

	public Store() {
    	System.out.print("Choose Product to review:\n");
    	String home = System.getProperty("user.home");
		File folder = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingStores");
		File[] listOfFiles = folder.listFiles();
    	for (int i = 0; i < listOfFiles.length; i++) {
      	  if (listOfFiles[i].isFile()) {
      	    System.out.println( listOfFiles[i].getName());
      	  } else if (listOfFiles[i].isDirectory()) {
      	    System.out.println("Directory " + listOfFiles[i].getName());
      	  }
      	}
      	Scanner Scan=new Scanner(System.in);
      	this.username=Scan.next();
      	folder = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingStores"+File.separator+this.username);
		
		
	try {
		Scan=new Scanner(folder);
        for(int i=0;i<4;i++) {
      	  switch(i) {
      	  case 0:
      		  this.Sname=Scan.nextLine();
      	  	  System.out.print(this.Sname+"\n");
      		
      		  break;
      	  case 1:
      		  this.Stype=Scan.nextLine();
      		  System.out.print(this.Stype+"\n");
      		  break;
      	  case 2:
      		  this.Slocation=Scan.nextLine();
      		  System.out.print(this.Slocation+"\n");
      		  break;
      	  case 3:
      		  this.username=Scan.nextLine();
      		  System.out.print(this.username+"\n");
      		  break;
      	  }
        }
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	String Source=home+File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingStores"+File.separator+this.username+"s.txt";
	String Destination=home+File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users" +this.username+File.separator+this.username+"s.txt";
	
	Scan=new Scanner(System.in);
	System.out.print("1.Add\n");
	System.out.print("2.Discard\n");
	int x=Scan.nextInt();
	if(x==1) {
      AlterFiles.moveFile(Source,Destination);
	}else if(x==2) {
	 
	 	AlterFiles.DeleteFile(Source);
	 	
	}else {
		System.out.print("Wrong input.\n");
	}

		

		
	}
	
public Store(String s1,String s2) {
		super(s1,s2);
		String home = System.getProperty("user.home");
		File file = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users"+ File.separator + s1 +File.separator+s1+"s.txt");
		File f = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingStores"+File.separator+s1+"s.txt");
        int w=0;
		Scanner Sc;
		
			try {
				Sc = new Scanner(file);
			
	          for(int i=0;i<4;i++) {
	        	  switch(i) {
	        	  case 0:
	        		  this.Sname=Sc.nextLine();	        	  	  	        		
	        		  break;
	        	  case 1:
	        		  this.Stype=Sc.nextLine();	        		  
	        		  break;
	        	  case 2:
	        		  this.Slocation=Sc.nextLine();	        		  
	        		  break;
	        	  case 3:
	        		  this.username=Sc.nextLine();
	        		  System.out.print(s1+"\n");
	        		  break;
	        	  }
	          }
	  		System.out.print("Hello Store Owner!.\n");
	  		System.out.print(this.Sname+"\n");
	  		System.out.print(this.Stype+"\n");
	  		System.out.print(this.Slocation+"\n");
	  	
	
	          w=1;
			}
	          catch (FileNotFoundException e) {
	        	  if(f.exists()) {
	        		  System.out.print("Request Pending for Admin Approval.\n");
	        	  }else {
	        		  System.out.print("Your request had been rejected by the Admin.\n");
	        	  }
	        	  
			}
			if(w==1) {
		System.out.print("1.Add Product\n");
		System.out.print("2.Live Statistics\n");
		
		int A;
		Scanner Scan=new Scanner(System.in);
		A=Scan.nextInt();
		switch(A) {
		case 1:
			System.out.print("Enter Product name:");
			String in;
			in=Scan.next();
			Product product = new Product(in,this.username);
			break;
		case 2:
			Product p=new Product();
			p.LiveStat(this.username);
			break;
			
			
		default:
			System.out.print("Wrong input.");
		}
		}

}

	public Store(String s1,String s2,int x) {
		super(s1,s2,x);
		Scanner Scan=new Scanner(System.in);
		String home = System.getProperty("user.home");
		System.out.print("Enter Store Name:\n");
		this.Sname=Scan.next();
		File file = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingStores"+ File.separator +s1+"s.txt");
		
		try {
			file.createNewFile();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter writer;
		try {
			writer = new PrintWriter(file.getAbsoluteFile());
			writer.println(this.Sname);
			System.out.print("Enter Store Type:\n");
			this.Stype=Scan.next();
			writer.println(this.Stype);
			System.out.print("Enter Store Location:\n");
			this.Slocation=Scan.next();
			writer.println(this.Slocation);
			System.out.println("Signed-up!.");
			writer.close();
			Scan.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		

	}
}

