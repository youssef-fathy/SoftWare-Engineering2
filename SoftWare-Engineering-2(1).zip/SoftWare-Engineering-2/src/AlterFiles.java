import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public interface AlterFiles {
	
static void moveFile(String src, String dest ) {
	    Path result = null;
	    try {
	       result =  Files.move(Paths.get(src), Paths.get(dest));
	    } catch (IOException e) {
	       System.out.println("Exception while moving file: " + e.getMessage());
	    }
	    if(result != null) {
	       System.out.println("File added.");
	    }else{
	       System.out.println("File movement failed.");
	       
	    }  
	 }


	static void DeleteFile(String src) {
	    File file = new File(src); 
	    
	    if(file.delete()) 
	    { 
	        System.out.println("File Discarded."); 
	    } 
	    else
	    { 
	        System.out.println("Failed to delete the file"); 
	    } 
	}
	



    	
}

