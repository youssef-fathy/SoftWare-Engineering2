import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;


public class Product implements AlterFiles {

	private String distrbutor;
	private String Name;
	private Double price;
	private String Brandname;
	private String Category;
	private int Quantity;
	private String[] Products;
	
	public Product() {
		
		
	}


	public Product(String name,String UN) {
		

		String home = System.getProperty("user.home");
		Scanner Scan=new Scanner(System.in);
		File f = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingProducts"+ File.separator + name +".txt");
		 
			try {
				f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
	        PrintWriter writer;
			try {
				writer = new PrintWriter(f.getAbsolutePath());
				this.distrbutor=UN;
				writer.println(this.distrbutor);
				this.Name=name;
				writer.println(this.Name);
				System.out.print("Enter Product price:\n");
				this.price=Scan.nextDouble();
				writer.println(this.price);
				PlatForm PF=new PlatForm(this.Name);
				PF.getBrand();
				System.out.print("Enter Product Brandname:\n");
				this.Brandname=Scan.next();
				writer.println(this.Brandname);

				System.out.print("Enter Product Category:\n");
				this.Category=Scan.next();
				writer.println(this.Category);
				System.out.print("Enter Product Quantity:\n");
				this.Quantity=Scan.nextInt();
				writer.println(this.Quantity);
				Scan.close();
				writer.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


	}

   
public Product(int x) {
    	System.out.print("Choose Product to review:\n");
    	String home = System.getProperty("user.home");
		File folder = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingProducts");
		File[] listOfFiles = folder.listFiles();
		

    	for (int i = 0; i < listOfFiles.length; i++) {
    	  if (listOfFiles[i].isFile()) {
    	    System.out.println( listOfFiles[i].getName());
    	  } else if (listOfFiles[i].isDirectory()) {
    	    System.out.println("Directory " + listOfFiles[i].getName());
    	  }
    	}
    	Scanner Scan=new Scanner(System.in);
    	this.Name=Scan.next();
    	folder = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingProducts"+ File.separator +this.Name);
    	try {
			Scan=new Scanner(folder);
			for(int i=0;i<6;i++) {
				switch(i) {
				case 0:
					this.distrbutor=Scan.next();
					System.out.print("Product Distrbutor:"+this.distrbutor+"\n");
				break;
				case 1:
			    	this.Name=Scan.next();
					System.out.print("Product Name:"+this.Name+"\n");
					break;
				case 2:
					this.price=Scan.nextDouble();
					System.out.print("Product Price:"+this.price+"\n");
					break;
				case 3:
					this.Brandname=Scan.next();
					System.out.print("Product Brandname:"+this.Brandname+"\n");
					break;
				case 4:
					this.Category=Scan.next();
					System.out.print("Product Category:"+this.Category+"\n");
					break;
				case 5:
					this.Quantity=Scan.nextInt();
					System.out.print("Product Quantity:"+this.Quantity+"\n");
					break;
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	Scan=new Scanner(System.in);
    	System.out.print("1.Add\n");
    	System.out.print("2.Discard\n");
    	x=Scan.nextInt();
    	if(x==1) {
        	String Source=home+File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingProducts" + File.separator + this.Name +".txt";
        	String Destination=home+File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator +"Products" + File.separator + this.Name +".txt";
        	File f=new File(home+File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users"+File.separator+this.distrbutor + File.separator +"Products.txt");
        	String[] ArrayList=null;
        	String input=null;
        	try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		try {
				Scan=new Scanner(f);
				if(Scan.hasNextLine()) {
				input=Scan.nextLine();
				//System.out.print(input+"\n");
	    		String K="-";
	    		ArrayList=input.split(K);
	    		Products=new String[ArrayList.length+1];
				PrintWriter writer=new PrintWriter(f.getAbsolutePath());
				for(int i=0;i<ArrayList.length;i++) {
			
					Products[i]=ArrayList[i];
					writer.write(Products[i]+"-");
			
				}
				writer.write(this.Name+"-");
				writer.flush();
				writer.close();
				}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		
    
    

            AlterFiles.moveFile(Source,Destination);
    	}else if(x==2) {
    	 	String Source=home+File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "PendingProducts" + File.separator + this.Name +".txt";
    	 	AlterFiles.DeleteFile(Source);
    	 	
    	}else {
    		System.out.print("Wrong input.\n");
    	}


    	
   
    }



public void LiveStat(String UN) {

	String home = System.getProperty("user.home");
	File f=new File(home+File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users"+File.separator+UN + File.separator +"Products.txt");
	String[] ArrayList=null;
	String input=null;
	Scanner Scan;
	try {
		Scan = new Scanner(f);
		if(Scan.hasNextLine()) {
			input=Scan.nextLine();
			//System.out.print(input+"\n");
			String K="-";
			ArrayList=input.split(K);
			Products=new String[ArrayList.length+1];
			for(int i=0;i<ArrayList.length;i++) {

				Products[i]=ArrayList[i];
				System.out.print(i+1+"."+Products[i]+"\n");
			}
			
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.print("Enter product to show live statistics:\n");
	Scan=new Scanner(System.in);
	String Y=Scan.next();

	Random rand=new Random();
		int PV= rand.nextInt(1000);
		System.out.print("number of product views:"+PV+"\n");
		int BP=rand.nextInt(10);
		System.out.print("number of product bought:"+BP+"\n");
		this.Quantity=rand.nextInt(50);
		if(this.Quantity==0) {
			System.out.print("this product is sold out.");
		}else {
			System.out.print("this product is in stock.");
		}
		
	}

}
