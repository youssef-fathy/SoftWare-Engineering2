import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Admin extends MainInfo{

	public Admin() {
		super();
		System.out.print("Hello Admin !.\n");
	}

	public Admin(String s1, String s2) {
		super(s1, s2);
		System.out.print("Hello Admin !.\n");
		System.out.print("1.Add a Product.\n");
		System.out.print("2.Add a Store.\n");
		System.out.print("3.Add a Category.\n");
		System.out.print("4.Add a Brand.\n");
		Scanner Scan=new Scanner(System.in);
		int x=Scan.nextInt();
		switch(x) {
		case 1:
			Product product=new Product(x);
			break;
		case 3:
			try {
				PlatForm addcat=new PlatForm();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			Store store=new Store();
			break;
		case 4:
			
				PlatForm addbrand=new PlatForm(x);
		
			break;
		default:
			System.out.print("Wrong input.\n");
		}
		
}


	

	

}
