
public class Buyer extends MainInfo{

	String[] Basket;
	
	
	
	public Buyer() {
		super();
	}



	public Buyer(String s1,String s2) {
		super(s1,s2);
		
		System.out.print("Hello Buyer!.\n");
	}



	public Buyer(String s1,String s2,int x) {
		super(s1,s2,x);
		System.out.println("Signed-up!.");
	}

}
