import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MainInfo {
	protected String username;
	protected String password;
	protected String usertype;
	protected int age;
	protected int phone;

	public MainInfo() {
		// TODO Auto-generated constructor stub
	}
	public MainInfo(String UN ,String UT,int x) {    //Sign-up
		String home = System.getProperty("user.home");
		Scanner Scan=new Scanner(System.in);
		File f1 = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users"+ File.separator + UN );
		File f2 = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users"+ File.separator + UN +File.separator+"maininfo.txt");
		
		f1.mkdir();
		
		
		try {
			f2.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block`
			e.printStackTrace();
		}
        PrintWriter writer;
		try {
			writer = new PrintWriter(f2.getAbsolutePath());
			this.username=UN;
	        writer.println(this.username);
		    System.out.print("Enter password:\n");
			this.password=Scan.next();
			writer.println(this.password);
			this.usertype=UT;
	        writer.println(this.usertype);
	        System.out.print("Enter age:\n");
			this.age=Scan.nextInt();
	        writer.println(this.age);
	        System.out.print("Enter phone:\n");
			this.phone=Scan.nextInt();
	        writer.println(this.phone);
	        writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	


}
	
	
	
	
	public MainInfo(String UN,String PW)  {   //Sign-in
		String home = System.getProperty("user.home");
		File f = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users"+ File.separator + UN +File.separator+"maininfo.txt");
          Scanner Sc;
		try {
			Sc = new Scanner(f);
	          for(int i=0;i<5;i++) {
	        	  switch(i) {
	        	  case 0:
	        		  this.username=Sc.nextLine();
	        		  break;
	        	  case 1:
	        		  this.password=Sc.nextLine();
	        		  break;
	        	  case 2:
	        		  this.usertype=Sc.next();
	        		  break;
	        	  case 3:
	        		  this.age=Sc.nextInt();
	        		  break;
	        	  case 4:
	        		  this.phone=Sc.nextInt();
	        		  break;
	        		  
	        	  }
	          }
		} catch (FileNotFoundException e) {
			System.out.print("User not found.\n");
		}

		String Str1=this.password;
		if(PW.equals(Str1)) {
			System.out.print("Signed-in.\n");


			
		}
		else {
			System.out.print("Wrong password.\n");
			System.exit(404);

			
		}
}
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	
	
	

	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	public String getUsertype(String s) {
	String home = System.getProperty("user.home");
		File f = new File(home + File.separator + "Desktop" + File.separator + "Eclipse-Workspace"+ File.separator + "Software-Engineering-2"+ File.separator + "Users"+ File.separator + s + File.separator +  "maininfo.txt");
          Scanner Sc;
		try {
			Sc = new Scanner(f);
			for(int i=0;i<3;i++) {
			
					usertype=Sc.next();
				
			}
			Sc.close();
	} catch (FileNotFoundException e) {
		System.out.print("User not found.\n");
	}
		finally{

			return usertype;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
	public void setUsertype(String s2) {
		this.usertype=s2;
	}
} 
